package es.iesmz.tests;

public class Money {
    private static final float eurousd = 1.8798;
    private static final float usdeuro = 0,841815;
}



